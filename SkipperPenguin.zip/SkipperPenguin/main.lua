
SMODS.Joker {
    key = "skipper",
    pos = { x = 0, y = 0 },
    rarity = 1,
    blueprint_compat = true,
    cost = 1,
    atlas = 'Jokers', pos = { x = 0, y = 0 },
    config = { extra = { chips = 50 }, }, unlocked = true, discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                chips = card.ability.extra.chips
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
            play_sound('sp_TudoFudendo', 1, 0.5)
            return {
                    message = 'Tudo Fudendo!'
                }
        end
    end
}
-- Penguin Deck
SMODS.Back {
    key = "penguin",
    pos = { x = 0, y = 0 },
    atlas = 'Decks', pos = { x = 0, y = 0 },
    config = { joker_slot = 1 },
    unlocked = true,
    loc_vars = function(self, info_queue, back)
        return { vars = { self.config.joker_slot } }       
    end,
    apply = function(self)
          G.E_MANAGER:add_event(Event({
            func = function()
              local card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_sp_skipper', nil)
              card:add_to_deck()
              card:set_eternal(true)
              G.jokers:emplace(card)
              return true
            end
          }))
    end
}

SMODS.Atlas {
    key = "Jokers",
    path = "Jokers.png",
    px = 71,
    py = 95
}

SMODS.Atlas {
    key = "Decks",
    path = "Decks.png",
    px = 71,
    py = 95
}

SMODS.Atlas {
    key = "modicon",
    path = "Icon.png",
    px = 32,
    py = 32
}

SMODS.Sound{
    key = "TudoFudendo",
    path = {
 	['default'] = 'tudo_fudendo.ogg'
 }
}