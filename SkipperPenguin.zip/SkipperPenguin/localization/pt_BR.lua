return {
    descriptions = {
        Back={
            -- this should be the full key of your object, including any prefixes
            b_sp_penguin = {
                name = 'Baralho Pinguim',
                text = { '{C:attention}+1{} Espaco de Coringa',
                'comeca com um {C:attention}Capitao Eterno{}'
                },
            },
        },
        Blind={},
        Edition={},
        Enhanced={},
        Joker = {
            -- this should be the full key of your object, including any prefixes
            j_sp_skipper = {
                name = 'Capitao',
                text = { '{C:chips}+50{} fichas',
                'exclama {C:purple}Tudo Fudendo!{}',
                'quando um {C:attention}Blind{} e derrotado'
                },
            },
        },
        Other={},
        Planet={},
        Spectral={},
        Stake={},
        Tag={},
        Tarot={},
        Voucher={},
    },
    misc = {
        achievement_descriptions={},
        achievement_names={},
        blind_states={},
        challenge_names={},
        collabs={},
        dictionary={},
        high_scores={},
        labels={},
        poker_hand_descriptions={},
        poker_hands={},
        quips={},
        ranks={},
        suits_plural={},
        suits_singular={},
        tutorial={},
        v_dictionary={},
        v_text={},
    },
}